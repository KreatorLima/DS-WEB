let nome = prompt("Qual é o seu nome?");
let sobrenome = prompt("Qual é o seu sobrenome?");

document.body.innerHTML = `<h1>Olá, ${nome} ${sobrenome}!</h1>`;