let numero = Number(prompt("Digite um número:"));
let potencia = numero ** 3;
alert(`O número ${numero} elevado ao cubo é ${potencia}.`);