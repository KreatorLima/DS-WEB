let numero1 =Number(prompt("Digite um número:"));
let numero2 =Number(prompt("Digite outro número:"));
alert(numero1 + numero2);

let numero3 =Number(prompt("Digite um número:"));
let numero4 =Number(prompt("Digite outro número:"));
alert(numero3 - numero4);

let numero5 =Number(prompt("Digite um número:"));
let numero6 =Number(prompt("Digite outro número:"));
alert(numero5 * numero6);

let numero7 =Number(prompt("Digite um número:"));
let numero8 =Number(prompt("Digite outro número:"));
alert(numero7 / numero8);