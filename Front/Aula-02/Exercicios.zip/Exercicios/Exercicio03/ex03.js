function fundoAzul() {
      document.body.style.backgroundColor = "blue";
      document.getElementById("titulo").innerText = "Página Azul";
    }

    function fundoVerde() {
      document.body.style.backgroundColor = "green";
      document.getElementById("titulo").innerText = "Página Verde";
    }

    function fundoVermelho() {
      document.body.style.backgroundColor = "red";
      document.getElementById("titulo").innerText = "Página Vermelha";
    }